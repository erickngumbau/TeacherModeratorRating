package com.example.teacher_moderatorrating;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class AddTeacherandModeratorActivity extends AppCompatActivity {

    private EditText name,school,desc;
    private ImageView imageView;
    private TextView upload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_teacherand_moderator);

        name=findViewById(R.id.name);
        school=findViewById(R.id.school);
        desc=findViewById(R.id.description);
        imageView=findViewById(R.id.image);
        upload=findViewById(R.id.imgupload);
    }
}