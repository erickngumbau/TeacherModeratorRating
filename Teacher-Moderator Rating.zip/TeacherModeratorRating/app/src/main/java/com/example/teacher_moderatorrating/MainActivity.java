package com.example.teacher_moderatorrating;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Student studentmodel;

    private RelativeLayout loginlay,signuplay,adminlayout;
    private TextView login,signup;
    private Button student,admin;
    private DatabaseHelper databaseHelper;
    private EditText username,password,signupusername,signuppassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login = findViewById(R.id.login);
        signup=findViewById(R.id.signup);

        loginlay=findViewById(R.id.loginlayout);
        signuplay=findViewById(R.id.signuplayout);
        adminlayout=findViewById(R.id.adminsignuplayout);
        student=findViewById(R.id.btnsave);
        admin=findViewById(R.id.adminbtnsave);

        username =findViewById(R.id.username);
        password=findViewById(R.id.password);

        signupusername =findViewById(R.id.username1);
        signuppassword=findViewById(R.id.password1);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                databaseHelper = new DatabaseHelper(MainActivity.this);


                String usern=username.getText().toString().trim();
                String passw=password.getText().toString().trim();
                boolean check=databaseHelper.checkstudent(usern,passw);

                if(check){
                    Intent intent = new Intent(MainActivity.this,ModeratorRecyclerActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(MainActivity.this, "The Password and Username dont match", Toast.LENGTH_SHORT).show();
                }


                //todo if admin
//                Intent intent = new Intent(MainActivity.this,AdminWorkActivity.class);
//                startActivity(intent);
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                loginlay.setVisibility(View.INVISIBLE);
                signuplay.setVisibility(View.VISIBLE);

                databaseHelper = new DatabaseHelper(MainActivity.this);
                String nm = signupusername.getText().toString().trim();
                String psw = signupusername.getText().toString().trim();
                final boolean stdtadd=databaseHelper.addStudent(nm,psw);

                student.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(stdtadd){
                            loginlay.setVisibility(View.VISIBLE);
                            signuplay.setVisibility(View.INVISIBLE);
                        }
                        else {
                            Toast.makeText(MainActivity.this, "Erick sth happened", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });

        //todo : work on signup if user == admin/
        /*
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginlay.setVisibility(View.INVISIBLE);
                signuplay.setVisibility(View.VISIBLE);
            }
        });
         */
    }
}